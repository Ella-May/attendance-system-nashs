<span wire:click="destroy" class="d-sm-inline d-none">Sign
    Out</span>
<?php /**PATH C:\laragon\www\attendance-system-nashs\resources\views/livewire/auth/logout.blade.php ENDPATH**/ ?>