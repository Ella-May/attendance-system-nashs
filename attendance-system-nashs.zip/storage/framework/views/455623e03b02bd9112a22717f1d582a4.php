
<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur"
    navbar-scroll="true">
    <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
            <h6 class="font-weight-bolder mb-0 text-capitalize"><?php echo e(str_replace(array('-', '.'), ' ', Route::currentRouteName())); ?></h6>
        </nav>
        <div class="collapse navbar-collapse d-flex justify-content-end mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
            <form method="POST" action="" class="d-none" id="logout-form">
                <?php echo csrf_field(); ?>
            </form>
            <ul class="navbar-nav  justify-content-end">
                <li class="nav-item d-flex align-items-center">
                    <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                        <i class="fa fa-user me-sm-1"></i>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.logout', [])->html();
} elseif ($_instance->childHasBeenRendered('HGVVQI6')) {
    $componentId = $_instance->getRenderedChildComponentId('HGVVQI6');
    $componentTag = $_instance->getRenderedChildComponentTagName('HGVVQI6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HGVVQI6');
} else {
    $response = \Livewire\Livewire::mount('auth.logout', []);
    $html = $response->html();
    $_instance->logRenderedChild('HGVVQI6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </a>
                </li>
                <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
                    <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                        <div class="sidenav-toggler-inner">
                            <i class="sidenav-toggler-line"></i>
                            <i class="sidenav-toggler-line"></i>
                            <i class="sidenav-toggler-line"></i>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\attendance-system-nashs\resources\views/components/navbars/navs/auth.blade.php ENDPATH**/ ?>