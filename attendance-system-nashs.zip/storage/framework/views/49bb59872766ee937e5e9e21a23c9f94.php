<div>
    
    <h2>Scan here</h2>

    <button type="button" id="scan">Scan QR</button>
    <video id="preview" width="100%"></video>
</div>
<?php /**PATH C:\laragon\www\attendance-system-nashs\resources\views/livewire/q-r-code-scanner.blade.php ENDPATH**/ ?>