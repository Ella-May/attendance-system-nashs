<aside
    class="sidenav navbar navbar-vertical navbar-expand-xs border-0 fixed-start bg-gradient-dark"
    id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0 d-flex text-wrap align-items-center" href=" <?php echo e(route('dashboard')); ?> ">
                <img src="<?php echo e(asset('assets')); ?>/img/nashs-logo.png" class="navbar-brand-img h-100" alt="main_logo">
                <span class="ms-2 font-weight-bold text-white">Ninoy Aquino Senior High School</span>
            </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div>
        <ul class="navbar-nav">
            
            
            
            
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'dashboard' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('dashboard')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Administrative Management</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'user-account' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('user-account')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">group</i>
                    </div>
                    <span class="nav-link-text ms-1">User Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'create-account' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('create-account')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">group_add</i>
                    </div>
                    <span class="nav-link-text ms-1">Create Account</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Transaction Process</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'qrcode-scanner' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('qrcode-scanner')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">qr_code_scanner</i>
                    </div>
                    <span class="nav-link-text ms-1">QR Code Scanner</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'qrcode-generator' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('qrcode-generator')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">qr_code</i>
                    </div>
                    <span class="nav-link-text ms-1">Student QR Code Generator</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'attendance-report' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('attendance-report')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">text_snippet

                        </i>
                    </div>
                    <span class="nav-link-text ms-1">Attendance Report</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Information Management</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'student-information' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('student-information')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">diversity_3</i>
                    </div>
                    <span class="nav-link-text ms-1">Student Information</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'school-personnel' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('school-personnel')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">account_box</i>
                    </div>
                    <span class="nav-link-text ms-1">School Personnel</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'faculty-load' ? ' active bg-gradient-primary' : ''); ?> "
                    href="<?php echo e(route('faculty-load')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">article</i>
                    </div>
                    <span class="nav-link-text ms-1">Faculty Load</span>
                </a>
            </li>
            
            
            
            
            
        </ul>
    </div>
</aside>
<?php /**PATH C:\laragon\www\attendance-system-nashs\resources\views/components/navbars/sidebar.blade.php ENDPATH**/ ?>