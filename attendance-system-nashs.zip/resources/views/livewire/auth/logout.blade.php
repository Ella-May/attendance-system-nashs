<span wire:click="destroy" class="d-sm-inline d-none">Sign
    Out</span>
