<div class="mx-3 px-4">
    <h3>Scan QR Code here</h3>
</div>

<div class="text-center mb-3">
        <div class="d-flex gap-2 align-items-center justify-content-center">
            <button type="button" id="scanQR" class="btn btn-primary mb-3">Scan QR</button>
</div>
<video id="preview" width="100%"></video>
