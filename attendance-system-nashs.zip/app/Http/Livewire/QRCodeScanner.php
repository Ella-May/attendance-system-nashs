<?php

namespace App\Http\Livewire;

use Livewire\Component;

class QRCodeScanner extends Component
{
    public function render()
    {
        return view('livewire.q-r-code-scanner');
    }
}
